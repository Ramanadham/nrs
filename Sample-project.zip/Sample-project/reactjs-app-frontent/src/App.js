import React, { Component } from "react";
import Chart from "react-google-charts";
import config from "./config.json";
import http from "./services/httpServices";
import _ from "lodash";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "chart.js";
import Tabs from "./Tabs";
// import { Tabs, Tab } from "react-bootstrap-tabs";
const apiEndpoint = "http://localhost:3001/reports/";
const apiEndpointbyBarnd = "http://localhost:3001/reportsbybrand/";
class App extends Component {
  state = {
    selectedWeek: "Select Week",
    selectedConfigType: "Select Config Type",
    reportsData: [],
    lastWeekReportsData: [],
    nextWeekReportsData: [],
    configTypes: config.configTypes,
    loaderState: false,
    btnStates: false,
    configName: ""
  };

  getReportsByBrand = async (configType, sDate, eDate) => {
    return await http.get(
      apiEndpointbyBarnd + configType + "/" + sDate + "/" + eDate + ""
    );
  };
  handleWeekChange = event => {
    const selectedWeek = event.target.value;
    this.setState({ selectedWeek });
  };
  handleConfigChange = event => {
    let selectedConfigType = event.target.value;
    this.setState({ selectedConfigType });
    this.state.configTypes.filter(item => {
      if (item.type === selectedConfigType) {
        this.setState({ configName: item.name });
      }
    });
  };

  getWeekStartDate = (w, y) => {
    let simple = new Date(y, 0, 1 + (w - 1) * 7);
    let dow = simple.getDay();
    let ISOweekStart = simple;
    if (dow <= 4) {
      ISOweekStart.setDate(simple.getDate() - simple.getDay() + 1);
    } else {
      ISOweekStart.setDate(simple.getDate() + 8 - simple.getDay());
    }
    return ISOweekStart;
  };
  getWeekDates = (startDate, daysToAdd) => {
    let aryDates = [];
    for (let i = 0; i <= daysToAdd; i++) {
      let currentDate = new Date(startDate);
      currentDate.setDate(currentDate.getDate() + i);
      aryDates.push(
        currentDate.getFullYear() +
          "-" +
          (currentDate.getMonth() + 1) +
          "-" +
          currentDate.getDate()
      );
    }

    return aryDates;
  };
  getCurrentWeekNumber = dt => {
    var tdt = new Date(dt.valueOf());
    var dayn = (dt.getDay() + 6) % 7;
    tdt.setDate(tdt.getDate() - dayn + 3);
    var firstThursday = tdt.valueOf();
    tdt.setMonth(0, 1);
    if (tdt.getDay() !== 4) {
      tdt.setMonth(0, 1 + ((4 - tdt.getDay() + 7) % 7));
    }
    return 1 + Math.ceil((firstThursday - tdt) / 604800000);
  };
  notify = () => toast("Wow so easy !");
  handleSubmit = () => {
    this.notify();
    if (
      this.state.selectedWeek !== "Select Week" &&
      this.state.selectedConfigType !== "Select Config Type"
    ) {
      this.setState({ loaderState: true });
      let startDate = new Date(
        this.getWeekStartDate(this.state.selectedWeek, 2019)
      );
      let aryDates = this.getWeekDates(startDate, 6);
      let queryStartDate = aryDates[0];
      let queryEndDate = aryDates[aryDates.length - 1];
      let getData = this.getReportsByBrand(
        this.state.selectedConfigType,
        queryStartDate,
        queryEndDate
      );
      getData.then(data => {
        let filterItems = data.data.data;
        this.setState({
          loaderState: false,
          btnStates: true,
          //reportsData: [],
          lastWeekReportsData: [],
          nextWeekReportsData: [],
          reportsData: filterItems
        });
      });
    } else {
      toast.success("Success Notification !", {
        position: toast.POSITION.TOP_CENTER
      });
    }
  };
  generateData = nav => {
    let getWeek = "";
    if (nav === "lastWeek") {
      getWeek = this.state.selectedWeek - 1;
    } else {
      getWeek = parseInt(this.state.selectedWeek) + 1;
    }

    let startDate = new Date(this.getWeekStartDate(getWeek, 2019));
    let aryDates = this.getWeekDates(startDate, 6);
    let queryStartDate = aryDates[0];
    let queryEndDate = aryDates[aryDates.length - 1];
    let getWeekData = this.getReportsByBrand(
      this.state.selectedConfigType,
      queryStartDate,
      queryEndDate
    );
    getWeekData.then(data => {
      let filterItems = data.data.data;
      if (nav === "lastWeek")
        this.setState({ lastWeekReportsData: filterItems });
      else this.setState({ nextWeekReportsData: filterItems });
    });
  };
  generateLastWeekChart = () => {
    this.generateData("lastWeek");
  };
  generateNextWeekChart = () => {
    this.generateData("nextWeek");
  };
  buildOptions = () => {
    var arr = [];
    let currentDate = new Date();
    let currentWeekNumber = this.getCurrentWeekNumber(currentDate);
    for (let i = 1; i <= 4; i++) {
      arr.push(
        <option key={i} value={i}>
          2019 Janauary Week-{i}
        </option>
      );
    }
    return arr;
  };
  generateChartHere = weekType => {
    let takeWeekState = "";
    if (weekType === "current") {
      takeWeekState = this.state.reportsData;
    } else if (weekType === "next") {
      takeWeekState = this.state.nextWeekReportsData;
    } else {
      takeWeekState = this.state.lastWeekReportsData;
    }
  };
  render() {
    let currentWeekChartData = this.state.reportsData;
    let lastWeekChartData = this.state.lastWeekReportsData;
    let nextWeekChartData = this.state.nextWeekReportsData;
    let currentWeekChart = [];
    currentWeekChart.push([
      "Element",
      "Average",
      { role: "style" },
      { role: "annotation" }
    ]);
    if (currentWeekChartData.length > 0) {
      for (let i = 0; i < currentWeekChartData.length; i++) {
        currentWeekChart.push([
          currentWeekChartData[i].brand.toUpperCase(),
          currentWeekChartData[i].keyIndicator,
          "rgb(51, 102, 204);",
          currentWeekChartData[i].keyIndicator
        ]);
      }
    }
    let lastWeekChart = [];
    lastWeekChart.push([
      "Element",
      "Average",
      { role: "style" },
      { role: "annotation" }
    ]);
    if (lastWeekChartData.length > 0) {
      currentWeekChartData.forEach(function(item, index, array) {
        let ItemIndex = lastWeekChartData.findIndex(
          b => b.keyIndicator === item.keyIndicator
        );
        if (ItemIndex === -1) {
          lastWeekChartData[index].missMatch = true;
        }
      });
      for (let i = 0; i < lastWeekChartData.length; i++) {
        let color;
        if (lastWeekChartData[i].missMatch == true) {
          color = "red";
        } else {
          color = "rgb(51, 102, 204)";
        }
        lastWeekChart.push([
          lastWeekChartData[i].brand.toUpperCase(),
          lastWeekChartData[i].keyIndicator,
          color,
          lastWeekChartData[i].keyIndicator
        ]);
      }
    }
    //Last week chart daata
    let nextWeekChart = [];
    nextWeekChart.push([
      "Element",
      "Average",
      { role: "style" },
      { role: "annotation" }
    ]);

    if (nextWeekChartData.length > 0) {
      currentWeekChartData.forEach(function(item, index, array) {
        let ItemIndex = nextWeekChartData.findIndex(
          b => b.keyIndicator === item.keyIndicator
        );
        if (ItemIndex === -1) {
          nextWeekChartData[index].missMatch = true;
        }
      });
      for (let i = 0; i < nextWeekChartData.length; i++) {
        let color;
        if (nextWeekChartData[i].missMatch == true) {
          color = "red";
        } else {
          color = "rgb(51, 102, 204)";
        }
        nextWeekChart.push([
          nextWeekChartData[i].brand.toUpperCase(),
          nextWeekChartData[i].keyIndicator,
          color,
          nextWeekChartData[i].keyIndicator
        ]);
      }
      //console.log("Compare Here", compaare());
    }

    return (
      <React.Fragment>
        {/* <div className="container">
          <div className="row">
            <div className="col-sm-3">
              <div className="left-box" style={{ paddingTop: "30px" }}>
                <span className="col-h1">Metrics</span>
                <label className="cus-radio">
                  Performance
                  <input type="radio" defaultChecked name="metric" />
                  <span className="checkmark" />
                </label>
                <label className="cus-radio">
                  PWA
                  <input type="radio" name="metric" />
                  <span className="checkmark" />
                </label>
                <label className="cus-radio">
                  SEO
                  <input type="radio" name="metric" />
                  <span className="checkmark" />
                </label>
                <label className="cus-radio">
                  Best Practices
                  <input type="radio" name="metric" />
                  <span className="checkmark" />
                </label>
                <label className="cus-radio">
                  Accessibility
                  <input type="radio" name="metric" />
                  <span className="checkmark" />
                </label>
              </div>
              <div className="left-box" style={{ paddingTop: "30px" }}>
                <span className="col-h1">Brand</span>
                <label className="cus-radio">
                  Canan Digitaal
                  <input type="radio" defaultChecked name="brand" />
                  <span className="checkmark" />
                </label>
                <label className="cus-radio">
                  Diveo
                  <input type="radio" name="brand" />
                  <span className="checkmark" />
                </label>
                <label className="cus-radio">
                  HD Austria
                  <input type="radio" name="brand" />
                  <span className="checkmark" />
                </label>
                <label className="cus-radio">
                  Telesat
                  <input type="radio" name="brand" />
                  <span className="checkmark" />
                </label>
                <label className="cus-radio">
                  TV Vlaanderen
                  <input type="radio" name="brand" />
                  <span className="checkmark" />
                </label>
              </div>
              <div className="left-box" style={{ paddingTop: "30px" }}>
                <span className="col-h1">Period</span>
                <div>Current Week</div>
                <div>Next Week</div>
                <div>Previous Week</div>
              </div>
              <div className="left-box" style={{ paddingTop: "30px" }}>
                <span className="col-h1">Comparision</span>
                <div>Current Week</div>
                <div>Next Week</div>
                <div>Previous Week</div>
              </div>
            </div>
            <div className="col-sm-9">
              <div style={{ paddingTop: "30px" }}>
                <Tabs>
                  <div label="Data graph">
                    <div className="data-chart">
                      <div className="pad-30">Average Scores</div>
                      <div>
                        {currentWeekChartData.length > 0 && (
                          <div className="chart-grid">
                            <Chart
                              height={"300px"}
                              chartType="BarChart"
                              loader={<div>Loading Chart</div>}
                              data={currentWeekChart}
                              options={{
                                title:
                                  "Current Week-" + this.state.selectedWeek,
                                pieSliceText: "value",
                                legend: { position: "none" }
                              }}
                              rootProps={{ "data-testid": "1" }}
                            />
                          </div>
                        )}
                      </div>
                      <div className="compare-week">
                        <div>Week 30</div>
                        <div>Week 21</div>
                      </div>
                      <div style={{ textAlign: "center" }}>Metrics</div>
                    </div>
                  </div>
                  <div label="Trendline">
                    After &apos;while, <em>Crocodile</em>!
                  </div>
                </Tabs>
              </div>
            </div>
          </div>
        </div> */}
        <div className="container-fluid">
          <div className="row" style={{ backgroundColor: "#cdcdcd" }}>
            <div className="col-sm-3">
              <div className="select">
                <select
                  value={this.state.selectedConfigType}
                  onChange={this.handleConfigChange}
                >
                  <option value="Select Week">Select Configtype</option>
                  {this.state.configTypes.map(item => (
                    <option value={item.type} name={item.name} key={item.id}>
                      {item.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="col-sm-3">
              <div className="select">
                <select
                  value={this.state.selectedWeek}
                  onChange={this.handleWeekChange}
                >
                  <option value="Select Week">Select Week</option>
                  {this.buildOptions()}
                </select>
              </div>
            </div>
            <div className="col-sm-6">
              {this.state.btnStates && this.state.selectedWeek > 1 && (
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={this.generateLastWeekChart}
                >
                  <i
                    className="fa fa-angle-double-left"
                    style={{
                      color: "white",
                      fontSize: "24px"
                    }}
                  />
                </button>
              )}
              <button
                type="button"
                className="btn btn-primary"
                onClick={this.handleSubmit}
              >
                Generate
              </button>

              {this.state.btnStates && this.state.selectedWeek > 0 && (
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={this.generateNextWeekChart}
                >
                  <i
                    className="fa fa-angle-double-right"
                    style={{
                      color: "white",
                      fontSize: "24px"
                    }}
                  />
                </button>
              )}
            </div>
          </div>
          {this.state.reportsData.length > 0 && (
            <div className="row" style={{ backgroundColor: "#EEE" }}>
              <div className="col-md-12">
                <p style={{ margin: "0", padding: "15px" }}>
                  Average - <strong>{this.state.configName}</strong>
                </p>
              </div>
            </div>
          )}

          {this.state.loaderState && (
            <div className="row">
              <div className="col-md-12">
                <div className="loader" />
              </div>
            </div>
          )}

          {this.state.reportsData.length > 0 && !this.state.loaderState && (
            <div className="row">
              <div className="col-md-12 reports-center">
                {lastWeekChartData.length > 0 && (
                  <div>
                    <Chart
                      height={"300px"}
                      width={"400px"}
                      chartType="BarChart"
                      loader={<div>Loading Chart</div>}
                      data={lastWeekChart}
                      options={{
                        title: "Last Week-" + (this.state.selectedWeek - 1),
                        pieSliceText: "value",
                        legend: { position: "none" }
                      }}
                      rootProps={{ "data-testid": "1" }}
                    />
                  </div>
                )}
                {currentWeekChartData.length > 0 && (
                  <div>
                    <Chart
                      height={"300px"}
                      width={"400px"}
                      chartType="BarChart"
                      loader={<div>Loading Chart</div>}
                      data={currentWeekChart}
                      options={{
                        title: "Current Week-" + this.state.selectedWeek,
                        pieSliceText: "value",
                        legend: { position: "none" }
                      }}
                      rootProps={{ "data-testid": "1" }}
                    />
                  </div>
                )}
                {nextWeekChartData.length > 0 && (
                  <div>
                    <Chart
                      height={"300px"}
                      width={"400px"}
                      chartType="BarChart"
                      loader={<div>Loading Chart</div>}
                      data={nextWeekChart}
                      options={{
                        title:
                          "Next Week-" +
                          (parseInt(this.state.selectedWeek) + 1),
                        pieSliceText: "value",
                        legend: { position: "none" }
                      }}
                      rootProps={{ "data-testid": "1" }}
                    />
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </React.Fragment>
    );
  }
}

export default App;
