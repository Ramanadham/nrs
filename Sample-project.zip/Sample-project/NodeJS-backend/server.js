var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var mysql = require("mysql");
var cors = require("cors");
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true
  })
);
app.use(cors());
// default route
app.get("/", function(req, res) {
  return res.send({ error: true, message: "hello" });
});
// connection configurations
var dbConn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Redfort@9518",
  database: "node_js_api"
});

// connect to database
dbConn.connect();
app.get("/getReports", function(req, res) {
  let configType = "pwa-score";
  let queryStr = "SELECT brand from reports";
  dbConn.query(queryStr, function(error, results, fields) {
    if (error) throw error;
    return res.send({
      error: false,
      data: results,
      message: "reports list."
    });
  });
});

app.get("/reportsbybrand/:configType/:sdate/:edate", function(req, res) {
  let startDate = req.params.sdate;
  let endDate = req.params.edate;
  let configType = req.params.configType;
  let queryStr =
    "SELECT brand,ANY_VALUE(`created_at`) as startDate, ROUND(AVG(" +
    "`" +
    configType +
    "`" +
    "),0) as  keyIndicator FROM reports WHERE created_at BETWEEN " +
    "'" +
    startDate +
    "'" +
    " AND " +
    "'" +
    endDate +
    "'" +
    " GROUP BY Brand";
   // console.log(queryStr);
  dbConn.query(queryStr, function(error, results, fields) {
    if (error) throw error;
    return res.send({
      error: false,
      data: results,
      message: "users list."
    });
  });
});
// Retrieve user with id
app.get("/reports/:brand/:configType/:sdate/:edate", function(req, res) {
  let brand = req.params.brand;
  let startDate = req.params.sdate;
  let endDate = req.params.edate;
  let configType = req.params.configType;
  //console.log("configType", configType);
  dbConn.query(
    "SELECT id,brand,url,created_at as startDate,`speed-index` as speedIndex," +
      "`" +
      configType +
      "`" +
      " as keyIndicator FROM reports where created_at BETWEEN " +
      "'" +
      startDate +
      "'" +
      " and " +
      "'" +
      endDate +
      "'" +
      " and brand=?",
    brand,
    function(error, results, fields) {
      if (error) throw error;
      return res.send({
        error: false,
        data: results,
        message: "users list."
      });
    }
  );
});

// set port
app.listen(3001, function() {
  console.log("Node app is running on port 3001");
});

module.exports = app;
